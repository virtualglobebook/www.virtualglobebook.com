Diagona Icons
Copyright (C) 2007 Yusuke Kamiyamane. All rights reserved.
The icons are licensed under a Creative Commons Attribution 3.0 license.
--------------------------------------------------------------------------------
If you want to remove the attribution, please purchase a royalty-free license.
http://www.pinvoke.com/